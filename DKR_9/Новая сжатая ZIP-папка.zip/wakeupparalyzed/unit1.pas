unit Unit1;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, ExtCtrls;

type

  { TForm1 }

  TForm1 = class(TForm)
    btnResetTImer: TButton;
    btnSetTime: TButton;
    CheckTimeTimer: TTimer;
    Label_Hours: TLabel;
    Label_Minutes: TLabel;
    OutStatusAlarm: TMemo;
    BottonPanel: TPanel;
    SetHourEdit: TEdit;
    SetMinutesEdit: TEdit;
    procedure btnResetTimerCLick(Sender: TObject);
    procedure btnSetTimeClick(Sender: TObject);
    procedure OnCheckTimeTimer(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    AlarmHour: Integer;
    AlarmMinute: Integer;
    AlarmEnabled: Boolean;
    AlarmRinging: Boolean;
    procedure AddStatus(const S: string);
  public
  end;

var
  Form1: TForm1;

implementation

{$R *.lfm}

{ TForm1 }

procedure TForm1.AddStatus(const S: string);
begin
  OutStatusAlarm.Lines.Add(FormatDateTime('hh:nn:ss', Time) + '  ' + S);
end;

procedure TForm1.FormCreate(Sender: TObject);
begin
  AlarmHour := 0;
  AlarmMinute := 0;
  AlarmEnabled := False;
  AlarmRinging := False;

  Constraints.MinWidth := 500;
  Constraints.MinHeight := 320;

  CheckTimeTimer.Enabled := True;
  CheckTimeTimer.Interval := 1000;

  OutStatusAlarm.Clear;
  AddStatus('Программа запущена');
  AddStatus('Будильник выключен');
end;

procedure TForm1.btnSetTimeClick(Sender: TObject);
begin
  AlarmHour := StrToIntDef(SetHourEdit.Text, -1);
  AlarmMinute := StrToIntDef(SetMinutesEdit.Text, -1);

  if (AlarmHour < 0) or (AlarmHour > 23) then
  begin
    AddStatus('Ошибка: часы должны быть от 0 до 23');
    Exit;
  end;

  if (AlarmMinute < 0) or (AlarmMinute > 59) then
  begin
    AddStatus('Ошибка: минуты должны быть от 0 до 59');
    Exit;
  end;

  AlarmEnabled := True;
  AlarmRinging := False;

  AddStatus('Будильник установлен на ' +
    Format('%.2d:%.2d', [AlarmHour, AlarmMinute]));
end;

procedure TForm1.btnResetTimerCLick(Sender: TObject);
begin
  AlarmEnabled := False;
  AlarmRinging := False;
  AddStatus('Будильник сброшен');
end;

procedure TForm1.OnCheckTimeTimer(Sender: TObject);
var
  h, m, s, ms: Word;
begin
  DecodeTime(Time, h, m, s, ms);

  if AlarmEnabled and (not AlarmRinging) then
  begin
    if (h = AlarmHour) and (m = AlarmMinute) and (s = 0) then
    begin
      AlarmRinging := True;
      AlarmEnabled := False;
      Beep;
      AddStatus('Будильник сработал!');
      ShowMessage('Будильник сработал!');
    end;
  end;
end;

end.
